import React from 'react';
import { Text } from 'bumbag';

function LoggedOutHome() {
  return <Text>Display your landing page here</Text>;
}

export default LoggedOutHome;
