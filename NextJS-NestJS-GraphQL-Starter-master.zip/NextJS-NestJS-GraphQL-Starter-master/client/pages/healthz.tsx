function Healthz() {
  return 'up';
}

export default Healthz;
