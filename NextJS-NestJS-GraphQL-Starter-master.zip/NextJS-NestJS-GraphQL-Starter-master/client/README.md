[![GitHub forks](https://img.shields.io/github/forks/tomanagle/GraphQL-Apollo-Next.js?style=for-the-badge)](https://github.com/tomanagle/GraphQL-Apollo-Next.js/network)
[![GitHub stars](https://img.shields.io/github/stars/tomanagle/GraphQL-Apollo-Next.js?style=for-the-badge)](https://github.com/tomanagle/GraphQL-Apollo-Next.js/stargazers)
[![Twitter](https://img.shields.io/twitter/url?style=social&url=https%3A%2F%2Fgithub.com%2Ftomanagle%2FGraphQL-Apollo-Next.js)](https://twitter.com/intent/tweet?text=Wow:&url=https%3A%2F%2Fgithub.com%2Ftomanagle%2FGraphQL-Apollo-Next.js)
### Getting started

```git clone git@github.com:tomanagle/GraphQL-Apollo-Next.js.git```

```cd GraphQL-Apollo-Next.js```

```yarn install```

```yarn dev```

Read the full article here: https://medium.com/@tomanagle/create-a-server-side-rendering-graphql-client-with-next-js-and-apollo-client-acd397f70c64
