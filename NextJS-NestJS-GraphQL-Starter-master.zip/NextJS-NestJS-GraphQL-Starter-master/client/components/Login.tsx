import * as React from 'react';
import LoginButtons from 'components/LoginButtons';

function Login() {
  return (
    <>
      <LoginButtons />
    </>
  );
}

export default Login;
